/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Flyweigth;

/**
 *
 * @author WIN11
 */

public class MainFlyweight {
    public static void main(String[] args) {
        Figura c1 = FiguraFactory.getCirculo("Rojo");
        c1.dibujar("Claro");

        Figura c2 = FiguraFactory.getCirculo("Rojo");
        c2.dibujar("Oscuro");

        Figura c3 = FiguraFactory.getCirculo("Azul");
        c3.dibujar("Claro");

        Figura c4 = FiguraFactory.getCirculo("Rojo");
        c4.dibujar("Medio");
    }
}

