/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Flyweigth;

/**
 *
 * @author WIN11
 */
public class Circulo implements Figura {
    private String color; // estado intrínseco

    public Circulo(String color) {
        this.color = color;
    }

    @Override
    public void dibujar(String relleno) {
        System.out.println("Dibujando circulo de color " + color + " con relleno " + relleno);
    }
}
