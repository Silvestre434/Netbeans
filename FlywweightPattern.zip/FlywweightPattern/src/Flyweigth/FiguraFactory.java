/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Flyweigth;
import java.util.HashMap;
/**
 *
 * @author WIN11
 */

public class FiguraFactory {
    private static final HashMap<String, Figura> circulos = new HashMap<>();

    public static Figura getCirculo(String color) {
        Figura circulo = circulos.get(color);

        if (circulo == null) {
            circulo = new Circulo(color);
            circulos.put(color, circulo);
            System.out.println("Creando círculo de color: " + color);
        }
        return circulo;
    }
}