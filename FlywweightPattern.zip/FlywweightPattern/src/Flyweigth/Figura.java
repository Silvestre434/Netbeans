/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Flyweigth;

/**
 *
 * @author WIN11
 */
public interface Figura {
    void dibujar(String color);
}
