/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Prototype;

/**
 *
 * @author WIN11
 */


public class MainPrototype {
    public static void main(String[] args) {
        Documento original = new Documento("Informe", "Contenido del informe académico");
        Documento copia = (Documento) original.clonar();

        System.out.println("Original: " + original);
        System.out.println("Copia: " + copia);
    }
}
    
