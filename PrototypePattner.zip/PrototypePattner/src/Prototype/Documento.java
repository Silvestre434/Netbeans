/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prototype;

/**
 *
 * @author WIN11
 */

public class Documento implements Prototype {
    private String titulo;
    private String contenido;

    public Documento(String titulo, String contenido) {
        this.titulo = titulo;
        this.contenido = contenido;
    }

    @Override
    public Prototype clonar() {
        return new Documento(this.titulo, this.contenido);
    }

    @Override
    public String toString() {
        return "Documento [Titulo: " + titulo + ", Contenido: " + contenido + "]";
    }
}
