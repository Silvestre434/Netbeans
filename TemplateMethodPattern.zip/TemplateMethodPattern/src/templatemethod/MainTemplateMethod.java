/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package templatemethod;

/**
 *
 * @author WIN11
 */

public class MainTemplateMethod {
    public static void main(String[] args) {
        Juego futbol = new Futbol();
        futbol.jugar();

        System.out.println("-------------------");

        Juego basket = new Basket();
        basket.jugar();
    }
}