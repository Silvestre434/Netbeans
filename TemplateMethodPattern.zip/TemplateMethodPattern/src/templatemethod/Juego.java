/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package templatemethod;

/**
 *
 * @author WIN11
 */

public abstract class Juego {
    // Método plantilla (template method)
    public final void jugar() {
        inicializar();
        empezar();
        finalizar();
    }

    // Métodos abstractos que las subclases deben implementar
    protected abstract void inicializar();
    protected abstract void empezar();
    protected abstract void finalizar();
}
