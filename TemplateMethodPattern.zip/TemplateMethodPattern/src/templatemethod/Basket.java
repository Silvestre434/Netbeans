/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package templatemethod;

/**
 *
 * @author WIN11
 */
public class Basket extends Juego {
    @Override
    protected void inicializar() {
        System.out.println("Preparando la cancha de basquet...");
    }

    @Override
    protected void empezar() {
        System.out.println("Comienza el partido de basquet.");
    }

    @Override
    protected void finalizar() {
        System.out.println("Finaliza el partido de basquet.");
    }
}
